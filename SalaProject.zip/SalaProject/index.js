// return a random elemement from arry

