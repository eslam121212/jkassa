<?php

use App\Http\Controllers\hock2;
use App\Http\Controllers\GEtTables;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\AuthTokenControoler;
use App\Http\Controllers\pointOfSaleController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});





Route::get('i', [App\http\Controllers\ProductController::class, 'index']);
Route::post('saveProductCode', [App\http\Controllers\ProductController::class, 'store'])->name('store.prodcut.code');


Route::get('/webhock', [AuthTokenControoler::class, 'getTokenWithCode']);
Route::get('/webhock2', [hock2::class, 'hock2']);
Route::post('/webhock2', [hock2::class, 'hock2']);

Route::get('point-of-sale', [pointOfSaleController::class, 'index']);
Route::get('get-products', [pointOfSaleController::class, 'Products']);
Route::get('get-products-tables', [GEtTables::class, 'products']);
Route::get('get-pos-products-tables', [GEtTables::class, 'PosProducts']);
